# Nexus Gate — Full Codebase Architecture Report

> Source: `workspace-9dc9c1a1-584f-4746-af04-a59c52db1e0d.tar` extracted into `/home/z/my-project`.
> Analysis completed by 5 parallel subagents (Tasks 2-3, 4, 5, 6, 7-8). Detailed per-area notes are in `/home/z/my-project/worklog.md`.

---

## 1. Project Identity

**Nexus Gate** is a production-ready Next.js attendance system for **Cebu Technological University (CTU) Danao campus**. Students scan rotating QR codes projected in class to check in; organizers get a live roster. The headline feature is an anti-cheating stack: 2 FPS rotating QR codes with sub-frame HMACs, multi-frame liveness checks, Ed25519-signed device-bound scan certificates, and an offline-first sync queue — all designed to defeat photo-replay, screenshot, and offline-replay attacks.

- License: MIT (© 2026 SketchyXenon)
- Target infra cost: $0/month on free tiers (Vercel Hobby + Supabase Free + Ably Free + Cloudflare Free)
- Scalability target: 2000–3000 users with 150–200 concurrent/min

---

## 2. Tech Stack (exact versions)

| Layer | Technology | Version |
|---|---|---|
| Framework | Next.js (App Router, Turbopack, standalone output) | **16.1.1** |
| UI runtime | React / React-DOM | **19.0.0** |
| Language | TypeScript | ^5 (strict mode, but `noImplicitAny: false`) |
| Package manager / runtime | Bun | ^1.3 |
| Styling | Tailwind CSS v4 (`@tailwindcss/postcss`) + shadcn/ui (new-york style, neutral baseColor, lucide icons) | v4 |
| DB ORM | Prisma + `@prisma/client` (dual schema: Postgres prod / SQLite dev) | **6.11.1** |
| Backend DB / Auth | Supabase (Postgres + Auth + RLS) | `@supabase/ssr` 0.12, `@supabase/supabase-js` 2.110 |
| WebAuthn / passkeys | `@simplewebauthn/browser` 13.3 + `@simplewebauthn/server` 13.3.2 | |
| Password hashing | bcryptjs (cost 12) | 3.0.3 |
| Realtime | **Ably** (REST + SDK) — replaces earlier Render socket.io mini-service | 2.23 |
| Rate limiting | `@upstash/ratelimit` + `@upstash/redis` (with in-memory dev fallback) | |
| Forms / validation | react-hook-form 7.60 + `@hookform/resolvers` + **Zod 4** | |
| Server state | TanStack Query 5.82 + TanStack Table 8.21 | |
| Client state | Zustand 5.0.6 | |
| Animations | framer-motion 12.23 | |
| QR | `qrcode.react` 4.2 (projection) + `jsqr` 1.4 (scanning) | |
| File parsing | exceljs 4.4, mammoth 1.12, papaparse 5.5, pdf-parse 2.4 | |
| Email | nodemailer 9.0 (Gmail SMTP) | |
| Observability | `@sentry/nextjs` 10.62 (3 configs: client/server/edge) | |
| Tests | Vitest 4.1.9 (node env, no DOM) | |
| i18n | next-intl 4.3 (present but not actively used) | |
| Edge caching | (removed — was Cloudflare Worker, optional) | |

UI primitives: ~55 shadcn/ui components in `src/components/ui/` (full radix-based set + sonner + vaul + cmdk + recharts + chart).

---

## 3. File & Directory Layout

```
/home/z/my-project/
├── src/
│   ├── app/
│   │   ├── api/                 # 44 route.ts files (43 domain + 1 health root)
│   │   ├── layout.tsx           # Only server component — fonts, SEO, providers
│   │   ├── page.tsx             # Client gate: maintenance → login → app-shell
│   │   ├── error.tsx            # Route error boundary (dev shows stack)
│   │   ├── global-error.tsx     # Catches layout-level errors (bare HTML)
│   │   └── globals.css          # Tailwind v4 + oklch amber/gold theme
│   ├── components/
│   │   ├── nexus/               # 14 custom app components + 10 view modules
│   │   │   └── views/           # dashboard, scanner, events, attendance,
│   │   │                        # overrides, whitelist, accounts, audit-logs,
│   │   │                        # profile, project-qr
│   │   ├── ui/                  # ~55 shadcn primitives
│   │   ├── providers.tsx        # TanStack Query + TooltipProvider
│   │   ├── sw-register.tsx      # PWA service-worker registration
│   │   └── theme-provider.tsx   # next-themes wrapper
│   ├── hooks/                   # 7 custom hooks
│   ├── lib/                     # 36 source modules + 9 *.test.ts files
│   └── proxy.ts                 # Middleware: CSRF + security headers
├── prisma/
│   ├── schema.prisma            # Postgres (prod, with @map snake_case)
│   └── schema.sqlite.prisma     # SQLite (dev, no @map)
├── supabase/migrations/         # 10 SQL migrations (0001 → 0010)
├── (cloudflare/ removed — was optional edge cache)
├── public/                      # manifest.json, sw.js, robots.txt, 3 SVG icons
├── db/custom.db                 # Local SQLite dev DB
├── Caddyfile                    # Reverse proxy — prod :80, dev :81
├── sentry.{client,server,edge}.config.ts
├── instrumentation.ts           # Sentry runtime bootstrap
├── vercel.json                  # 2 cron jobs (event-reminders 8am, cleanup 3am)
├── vitest.config.ts
└── 4 markdown docs: README, DOCUMENTATION, ARCHITECTURE-SECURITY, DEPLOYMENT-GUIDE
```

Counts: 218 non-git files extracted; 44 API routes; 14 nexus components + 10 views; 36 lib modules (plus 9 test files = ~262 unit tests); 7 hooks; 10 DB migrations; 11 DB tables; 3 Sentry configs.

---

## 4. Application Architecture

### 4.1 Request flow
```
Browser
  └── HTTPS → Vercel (or Caddy :81 in dev)
       └── Next.js 16 (port 3000)
            ├── src/proxy.ts (Edge middleware)
            │     • CSRF: same-origin Origin/Referer check on mutating routes
            │     • Security headers: strict CSP, X-Frame-Options, HSTS preload,
            │       Permissions-Policy (camera=self), Referrer-Policy, nosniff
            │     • Skips CSRF for /api/cron/* (cron-secret gated separately)
            ├── API routes (43 endpoints)
            │     • requireAuth(minimumRole) gate on every authenticated route:
            │         session → ACTIVE check → maintenance block →
            │         per-account rate limit (100/min) → role hierarchy check
            │     • 30-second in-memory account cache (INVALIDATE on mutations)
            │     • Audit log written on every mutating action (30+ action types)
            └── Prisma Client (service-role, bypasses RLS)
                 └── Supabase Postgres (RLS as defense-in-depth backstop)

Realtime (organizers only):
  Server: lib/realtime.ts → Ably REST publish to channel event:<eventId>
  Browser: useAttendanceSocket(eventId) → Ably SDK subscribe
           Falls back to React Query polling if NEXT_PUBLIC_ABLY_KEY unset

Offline scans:
  Browser: jsQR decodes → builds SignedCertificate (Ed25519 via IndexedDB device
           key) → enqueues to localStorage key ng_scan_queue_v2 (<1 ms)
  Drain: exponential backoff + jitter, posts to /api/attendance with deterministic
         idempotency key (cannot be regenerated to bypass dedup)
```

### 4.2 Single-route SPA pattern
The entire authenticated app lives at `/`. There is **no App Router nested routing** — `AppShell` holds a `useState<ViewId>` with 10 possible values and conditionally renders ONE view in `<main>`. Navigation surfaces: persistent left sidebar (desktop `md:flex`) and MobileNav drawer. Refresh always returns to dashboard — **no deep-linking to specific views**.

### 4.3 Composition tree
```
layout.tsx (SERVER — fonts, SEO, JSON-LD, viewport)
  └── ThemeProvider (next-themes, defaultTheme="light", enableSystem=false)
      └── Providers (TanStack QueryClient + TooltipProvider)
          └── page.tsx (CLIENT)
                ├── fetch /api/settings (maintenance) + useMe()
                ├── loading spinner
                ├── <MaintenanceScreen> (non-admin when maintenance on)
                ├── <ErrorBoundary><LoginScreen/></ErrorBoundary> (unauth)
                └── <ErrorBoundary><AppShell user={user}/></ErrorBoundary> (auth)
```

### 4.4 Role-based view switching (client-side, server-enforced)
| Role | Visible views |
|------|---------------|
| **ADMIN** | dashboard, whitelist, events, project-qr, attendance, overrides, accounts, audit-logs |
| **ORGANIZER** | dashboard, events, project-qr, attendance, overrides, profile |
| **USER** (student) | dashboard, scanner, profile |

Client `NAV` array filters by role; server `requireAuth(minimumRole)` is the real enforcement.

---

## 5. Authentication & Authorization

### 5.1 Auth model
- **Supabase Auth** is the identity provider (email/password, magic links, passkeys/WebAuthn, OAuth-ready).
- **NextAuth / Google OAuth env vars are stale** — `package.json` has no `next-auth` dependency; the env template still references them, but they're unused.
- Sessions are cookie-based via `@supabase/ssr`. The legacy JWT access/refresh code in `lib/auth.ts` and `lib/session.ts` is largely vestigial — `supabase-session.ts` is the live path.

### 5.2 Account lifecycle
- Registration creates `PENDING_VERIFICATION` accounts (no OTP — first successful login flips to `ACTIVE`).
- Orphan-account reconciliation: if a Supabase auth user was deleted via Dashboard, the corresponding `accounts` row is auto-cleaned on next register/login/forgot-password/magic-link/admin-create attempt.

### 5.3 Three sign-in methods
1. **Password** — Supabase `signInWithPassword` + app-layer brute-force lockout (5 fails → 15-min `lockedUntil`).
2. **Passkey / WebAuthn** — `@simplewebauthn/server` discoverable credentials. Challenge stored in `ng_passkey_challenge` httpOnly cookie (120 s). Login establishes session via admin.generateLink → anon verifyOtp (magiclink).
3. **Magic link** — Supabase `signInWithOtp` (enumeration-safe responses).

### 5.4 RBAC
- Three roles: `USER=1 < ORGANIZER=2 < ADMIN=3` (`lib/rbac.ts`).
- `requireAuth(minimumRole?, {exactRole?})` on every authenticated route — verifies session, re-queries account status (cached 30 s), checks maintenance mode, enforces per-account rate limit (100/min), then role check.
- Some routes use `exactRole:true` (e.g. `/api/attendance` scan is **USER-only**, blocking organizers/admins from scanning).

### 5.5 Brute-force / cooldown protections
- Login lockout: 5 failures → 15-min lockout.
- Password change: 30-day cooldown (first change exempt).
- Profile update: 30-day cooldown; program change allowed **once** (`courseModifiedAt`).
- All comparisons use `crypto.timingSafeEqual` (timing-safe).

### 5.6 Password reset security
- Recovery-only: `/api/auth/reset-password` decodes the JWT AMR claim and **only accepts `recovery` method**, rejecting `otp`/`magiclink` sessions — prevents stolen-session password takeover.
- Reset link valid 30 min; verification codes valid 10 min.

---

## 6. Anti-Cheating QR Scan Stack (the headline feature)

### 6.1 Two-tier rotating QR (lib/qr-token.ts)
- **Tier 1**: 15-second time blocks (±1 tolerance) — `eventId.timeBlock.blockHmac`
- **Tier 2**: 500 ms sub-frames, 30 per block — appends `.subFrame.subHmac`
- v8 (4-part) format with legacy v5 (3-part) fallback.

### 6.2 Multi-frame liveness (`verifySubFrameLiveness`)
- Scanner collects **≥3 consecutive sub-frames** (each with client-observed HMACs).
- Server requires the sub-frames to be temporally consecutive — defeats single-photo-replay attacks (a screenshot only captures one frame).

### 6.3 Ed25519 device-bound scan certificates (`lib/scan-certificate.ts`, `lib/device-key-*`)
- Browser generates an Ed25519 keypair on first visit, stored in IndexedDB (`extractable=true` required for JWK persistence, but the private key never leaves the device).
- Public key registered to the account (max 5 active devices/account, device-fingerprint uniqueness across accounts — `DEVICE_IN_USE` if reuse detected).
- Each scan produces a `SignedCertificate {certificate, signature}`:
  - `certificate = {eventId, token, scannedAt, nonce, deviceFingerprint, subFrames[]}`
  - `signature = Ed25519.sign(canon(certificate), devicePrivateKey)`
- Server verifies signature, recomputes fingerprint, checks revocation, then runs the 10-step pipeline below.

### 6.4 10-step server-side verification on `/api/attendance`
1. Zod `scanCertificateSchema` validation
2. Existing-attendance fast path (P2002 → idempotent `{alreadyPresent: true}`)
3. Ed25519 `verifySignedCertificate`
4. `validateCertificateTimestamp` (60 s forward / 24 h backward skew)
5. Fetch event (must be `active`)
6. `validateQrPayload` — HMAC recomputed against **`scannedAt`** (client scan time, NOT server sync time) — this is what enables offline-first behavior
7. `validateCertificateEventMatch`
8. `verifySubFrameLiveness` (≥3 consecutive sub-frames)
9. Strict eligibility (open-to-all OR exact `program`+`section` match)
10. Time-window check via `scannedAt` → atomic `eventAttendance.create` with `@@unique([eventId, accountId])` + `idempotency_key` unique

### 6.5 Idempotency
- `deriveIdempotencyKey = HMAC-SHA256(deviceFingerprint, eventId:nonce)` — deterministic, so re-draining a queued scan after partial success returns `{alreadyPresent: true}` instead of creating a duplicate.
- 24-hour TTL on the idempotency lookup.

### 6.6 Offline-first sync queue (`useScanQueue` hook)
- localStorage key `ng_scan_queue_v2` (v2 = new certificate format).
- Each item: `{id, eventId, signedCertificate, queuedAt, attempts, status, result?, error?}`.
- Drain: exponential backoff `min(30s, 1s × 2^attempts) + jitter(0..500ms)`. After 5 attempts → `failed` (kept for manual retry).
- "Send now" button on the Scanner view triggers immediate drain.

---

## 7. Database Schema

### 7.1 Prisma vs Supabase
- Two Prisma schemas describe the **same 11 models**:
  - `prisma/schema.prisma` — Postgres (prod), uses `@map`/`@@map` for snake_case DB columns.
  - `prisma/schema.sqlite.prisma` — SQLite (dev), camelCase columns, no `@map`.
- Supabase migrations create the actual Postgres tables; Prisma Client queries them via the service role.
- The two layers are kept in sync **manually** ("when adding/removing a field, update BOTH schema files identically").

### 7.2 Tables (11 total)
| Model | Table | Purpose |
|---|---|---|
| `Account` | `accounts` | Users (email, password_hash, role, status, student_id, program, section, organization_name, supabase_auth_uid, passkey_credential, failed_login_attempts, locked_until, last_password_change_at, notification_endpoint/keys, course_modified_at) |
| `AuthorizedStudent` | `authorized_students` | Pre-registered student roster (whitelist) |
| `VerificationToken` | `verification_tokens` | Email codes / magic-link tokens |
| `RefreshToken` | `refresh_tokens` | Rotating refresh tokens (HMAC-SHA256 hashed, unique) |
| `Event` | `events` | Class/event definition (title, event_secret UUID, scope, target_program, target_section, scheduled_at, ends_at, check_in/time_out windows, delegatable, delegation_enabled, status) |
| `EventAttendance` | `event_attendance` | Atomic check-in record (UNIQUE(event_id, account_id), idempotency_key unique, certificate_nonce unique, certificate_sub_frames JSON, device_fingerprint, scanned_at, scanned_at_client, source, time_out_at) |
| `AttendanceOverride` | `attendance_overrides` | Manual attendance entry (UNIQUE(event_id, student_id)) |
| `Notification` | `notifications` | In-app + push notifications |
| `AuditLog` | `audit_logs` | Append-only audit trail (actor_id, action, target_type, target_id, metadata JSONB, ip, user_agent) |
| `DeviceKey` | `device_keys` | Ed25519 public keys (JWK), fingerprint unique, max 5/account |
| `Setting` | `settings` | Key/value store (maintenance_mode, maintenance_message) |

### 7.3 Row-Level Security (RLS)
Enabled on **all 11 tables**. App connects via service role (bypasses RLS) — RLS is a defense-in-depth backstop if the anon key leaks.

| Table | RLS policy (authenticated role) |
|---|---|
| `accounts` | SELECT own OR admin; UPDATE own (guard trigger blocks sensitive cols — see below) |
| `events` | SELECT any authenticated (visibility enforced in app layer); writes service-role only |
| `event_attendance` | SELECT own OR admin; writes service-role only |
| `attendance_overrides` | SELECT if admin OR event owner; writes service-role only |
| `notifications` | SELECT + UPDATE own; create/delete service-role only |
| `audit_logs` | SELECT admin only; writes service-role only |
| `authorized_students` | SELECT if admin OR organizer; writes service-role only |
| `device_keys` | SELECT own; writes service-role only |
| `settings` | SELECT any authenticated; writes service-role only |
| `refresh_tokens`, `verification_tokens` | SELECT own; writes service-role only |

Anonymous role: **DENIED** on every table.

### 7.4 Critical guard trigger (`guard_account_columns`, migrations 0005 → 0009)
A BEFORE UPDATE trigger on `accounts` blocks changes to `role`, `status`, `student_id`, `failed_login_attempts`, `locked_until`, `password_hash` — but **only** when `current_setting('role', true)` returns `'authenticated'` or `'anon'` (REST API context). Skips enforcement for trusted backend (NULL role, service_role, postgres superuser).

- 0005 introduced the trigger but fired on ALL writes → Prisma's legitimate login/password-change/admin updates all returned 503.
- 0009 fixed this by making the trigger role-aware. This was a critical production bug.

### 7.5 Database views (defined in 0001, redefined in 0002)
1. `v_attendance_detail` — one row per attendance joined with event + account; computes `attendance_state`.
2. `v_accounts_detail` — account roster with computed `is_locked` / `is_active` flags.
3. `v_event_summary` — per-event counts (attendance_count, override_count, timed_out_count).

### 7.6 Indexes (v7 composite-first strategy, migration 0003)
- Dropped v1 single-column indexes, rebuilt as composites matching real query patterns.
- Examples: `accounts(role,status)`, `events(status,scheduled_at)`, `event_attendance(account_id,scanned_at)`, `audit_logs(action,created_at)`.
- Plus unique constraints on `accounts.email`, `accounts.student_id`, `event_attendance.idempotency_key`, `event_attendance.certificate_nonce`, `refresh_tokens.token_hash`, `device_keys.fingerprint`, `event_attendance.(event_id,account_id)`, `attendance_overrides.(event_id,student_id)`.
- ~40 indexes total.

### 7.7 Migration evolution (v1 → v10)
| # | Migration | Theme |
|---|---|---|
| 0001 | `init.sql` | Initial 10 tables, single-column indexes, RLS enabled (no policies), bootstrap admin (`admin@ctu.edu.ph` / `nexus123`), 3 views |
| 0002 | `settings_and_views` | Settings table, `organization_name` on accounts, `delegatable` on events, idempotent re-creation of views |
| 0003 | `strict_rls_indexes_v7` | v7 strict RLS policies, composite indexes, `is_admin()` helper, `last_password_change_at` |
| 0004 | `device_keys_certificates_v8` | `device_keys` table, certificate fields on `event_attendance` |
| 0005 | `security_hardening_scalability_v8` | Buggy guard trigger, UNIQUE(event_id,student_id) on overrides, CHECK constraints on enums, restrict `is_admin()` grant to `authenticated` |
| 0006 | `delegation_enabled_v10` | `delegation_enabled BOOLEAN` on events |
| 0007 | `fix_rls_auth_uid_type_cast` | `auth.uid()::text` cast (auth.uid is UUID, accounts.id is TEXT cuid) |
| 0008 | `passkey_credential_field` | `passkey_credential TEXT` on accounts (separated from `notification_keys`) |
| 0009 | `fix_guard_trigger_role_aware` | **Critical fix** — guard trigger was blocking all Prisma writes; now role-aware |
| 0010 | `supabase_auth_uid` | `supabase_auth_uid UUID UNIQUE` on accounts + partial index — bridge to `auth.users.id` |

---

## 8. API Surface (44 routes)

| Domain | Routes | Auth | Highlights |
|---|---|---|---|
| **Auth** (11) | `/auth/{callback, forgot-password, login, logout, magic-link, me, refresh, register, reset-password}` + passkey `login-options`/`login-verify`/`register-options`/`register-verify` | Public (except `/me` and passkey register) | Enumeration-safe; recovery-only password reset; brute-force lockout; orphan reconciliation; activates PENDING_VERIFICATION → ACTIVE |
| **Accounts** (4) | `/accounts` GET, `/accounts/create` POST, `/accounts/[id]` PATCH, `/accounts/[id]/delete` DELETE | ADMIN | Self-action guards; **last-admin guard** (blocks if ≤1 ACTIVE ADMIN); revokes refresh tokens on role/status change; `invalidateAccountCache(supabaseAuthUid)` |
| **Attendance** (3) | `/attendance` POST, `/attendance/override` POST, `/attendance/overrides` GET | USER (exact) / ORGANIZER | 10-step verification pipeline; atomic unique constraint; Ably publish; 24h offline grace; override idempotent via UNIQUE(event_id, student_id) |
| **Events** (5) | `/events` GET/POST, `/events/[id]` GET/PATCH/DELETE, `/events/[id]/{attendance,details,secret}` GET | ORGANIZER+ | Strict visibility rules (open-to-all OR exact program+section match); soft delete by default, `?hard=true` ADMIN-only; 4-condition QR delegation (org tag on both sides + delegationEnabled + tag match) |
| **Whitelist** (4) | `/whitelist` GET/POST, `/whitelist/[studentId]` DELETE, `/whitelist/{import-file,template}` | ORGANIZER+ (DELETE admin) | Multipart 10 MB cap; strict ext + MIME allowlist (.xlsx/.xls/.pdf/.docx/.csv); `parseFile` preview-only (no DB writes); batch `createMany` with `skipDuplicates`; .xlsx template via exceljs (replaces CVE-vulnerable `xlsx`) |
| **Profile** (3) | `/profile` GET/PATCH, `/profile/device-key` GET/POST, `/profile/password` POST | Any authed | 30-day cooldowns; program change once-only; max 5 device keys; ADMIN excluded from profile edit; OAuth accounts skip re-auth on password change |
| **Notifications** (3) | `/notifications` GET/POST, `/notifications/{status,subscribe}` GET/POST/DELETE | Any authed | SSRF defense on push endpoints (no localhost, no private IPs, no metadata endpoints, push-provider allowlist); `"in-app"` sentinel bypass |
| **Admin** (2) | `/admin/{cleanup,maintenance}` POST | ADMIN | Cleanup deletes expired tokens; maintenance toggles Settings rows |
| **Cron** (2) | `/cron/{cleanup,event-reminders}` GET+POST | CRON_SECRET (Bearer / Basic / headers / query / body) | CSRF bypassed in proxy.ts; event-reminders creates notifications 30 min before event start |
| **Dashboard** (1) | `/dashboard` GET | Any authed | USER: attended count + recent + eligible events; ORGANIZER/ADMIN: 4 stat cards + recent events + program/section counts |
| **Audit-logs** (1) | `/audit-logs` GET | ADMIN | Paginated; includes actor fullName+email; metadata JSON in tooltip |
| **Other** (3) | `/health` GET (public), `/settings` GET (public), `/` (root, stub) | None | Health has 2-stage DB check; Settings returns maintenance mode |

**Rate-limit presets** (lib/rate-limit.ts): `login`, `register`, `otp`, `scan` (per-account only — critical for school WiFi shared IP), `api`, `apiAccount` (auto on every authed route), `scanAccount`. Upstash in prod (fails **OPEN** on Upstash errors); in-memory dev fallback.

**Cache headers** per route: `public, s-maxage=30/3600` for settings/template; `private, s-maxage=15/30, swr=60/120` for list endpoints (events, attendance/overrides, audit-logs, whitelist, dashboard); `no-cache` for `/auth/me` and per-user state.

---

## 9. Frontend Components & Views

### 9.1 Nexus custom components (14)
| Component | Role |
|---|---|
| `app-shell.tsx` | Top-level authed shell. Sidebar + MobileNav + sticky header (online/offline badge, NotificationBell, ThemeToggle, role badge, FAQ). Renders one of 10 views. `useLogout`, `useSessionTimeout(true)` (30 min auto-logout, 25 min warning). |
| `confirm-dialog.tsx` | 2-step AlertDialog: warning → type-to-confirm (default `"DELETE"` case-insensitive). Used by all destructive actions. |
| `cookie-consent.tsx` | GDPR banner. `localStorage["ng_cookie_consent"]`. 1.5 s delay. |
| `dicebear-avatar.tsx` | SHA-256 name seed → `api.dicebear.com/7.x/shapes` (gender/ethnicity neutral). Initials fallback. |
| `error-boundary.tsx` | React class boundary. `Sentry.captureException` with componentStack. Three modes: full-page / compact / custom fallback. |
| `event-combobox.tsx` | cmdk + Popover. Searches title/program/section/scope/scheduledAt. |
| `event-details-dialog.tsx` | Lazy event detail. Status badge (live/upcoming/ended/cancelled), check-in/time-out windows, caller's own attendance row. |
| `info-modals.tsx` | Modal hub (terms/privacy/faq/bug) controlled by `window` `open-info-modal` CustomEvent. |
| `landing-page.tsx` | Marketing page. Hero + 3-step How-it-works + 6 feature cards + FAQ + CTA + footer. Floating-dots `AnimatedBackground` via framer-motion. |
| `login-screen.tsx` | 1446 LOC, 8-state machine: `landing → login → register → success → forgot → forgot-success → reset → reset-success`. Supabase PKCE `?code=` redirect + hash `access_token` + `type=recovery`. 3 sign-in methods. |
| `maintenance.tsx` | Two exports: `MaintenancePanel` (admin Card with Textarea + ConfirmDialog), `MaintenanceScreen` (full-screen Wrench animation for non-admins). |
| `nexus-logo.tsx` | Brand SVG: shield with QR-pattern squares. (DRY violation — duplicate `NexusLogo` local fn inside `login-screen.tsx`.) |
| `notification-bell.tsx` | Popover. `useNotifications`, `useMarkNotificationsRead`, `useNotificationStatus`, `useSubscribeNotifications`, `useUnsubscribeNotifications`. `Notification.requestPermission()`. Pseudo "in-app" subscription (VAPID noted as future). |
| `password-meter.tsx` | Visual bar (0-6 score) + label + tips. Uses **SAME** `scorePassword()` as server (`lib/password-strength.ts`) — UI accurately reflects backend acceptance. |
| `theme-toggle.tsx` | `next-themes useTheme()`. Icon button (Moon/Sun) + tooltip. |

### 9.2 Views (10, all `"use client"`, ~8200 LOC total)
| View | LOC | Roles | Highlights |
|---|---|---|---|
| `dashboard.tsx` | 799 | All (branched) | USER: profile-completion prompt + stats + history. ADMIN/ORGANIZER: 4 stat cards + recent events + program/section bars. ADMIN-only: MaintenancePanel + AnalyticsPanel (CSV export). |
| `whitelist.tsx` | 1036 | ADMIN, ORGANIZER | Roster manager. Imports CSV/Excel/DOCX/PDF ≤10 MB via XHR with progress. Paste-CSV preview. Downloadable template. Table + filters + pagination (50/page). |
| `events.tsx` | 1046 | ADMIN, ORGANIZER | Create-event form (title, scope, target program/section, delegatable, separate date/time, optional check-in/time-out windows). Events grid + past history. Filters: search (debounce 300 ms), scope, status, sort. Duplicate-to-form action. Soft/hard delete via ConfirmDialog. |
| `project-qr.tsx` | 809 | ADMIN, ORGANIZER | Projection view. `QRCodeCanvas` refreshed every 500 ms via `generateQrPayload` (Web Crypto HMAC). Fullscreen API. Live attendance sidebar (present/expected, turnout %, recent check-ins). `useAttendanceSocket`. |
| `scanner.tsx` | 878 | USER | Camera scanner. `jsQR`, downscale to 640 px, throttled 8 FPS. v8 multi-frame liveness: collects 3 consecutive sub-frames, signs certificate via device-key-client, enqueues via `useScanQueue`. Cooldown 1.5 s post-scan. Profile-completion prompt. **No direct API calls** — everything via queue. |
| `attendance.tsx` | 891 | ADMIN, ORGANIZER | Live roster. EventCombobox picker. Filters (program/section/source/search/8 sort keys). Pagination (50/page). CSV export. Realtime via `useAttendanceSocket` (Ably) → polling fallback. "Instant"/"Polling" badge. |
| `overrides.tsx` | 683 | ADMIN, ORGANIZER | Manual attendance entry. Missing-students list computed from `whitelist ∖ attendance`. Override history with filters. ConfirmDialog before create. |
| `accounts.tsx` | 1037 | ADMIN | User management. Search + role/status/sort filters. Suspend/activate, edit (Dialog), create (Dialog: ADMIN or ORGANIZER with strong-password), delete (soft/hard). |
| `audit-logs.tsx` | 265 | ADMIN | Append-only log viewer. Action + actor filters. Color-toned badges. Pretty-printed JSON metadata in Tooltip. |
| `profile.tsx` | 761 | ORGANIZER, USER | Self-service profile. Header (avatar, role/status badges). Edit-profile card (excluded for ADMIN). Passkey registration (WebAuthn). Change-password Dialog. |

---

## 10. Hooks (7 custom)

| Hook | Purpose |
|---|---|
| `use-attendance-socket.ts` | Ably Realtime subscriber. `{connected, latest}`. Falls back to polling if `NEXT_PUBLIC_ABLY_KEY` unset or disconnected. |
| `use-debounce.ts` | Generic value debouncer (default 300 ms). |
| `use-mobile.ts` | shadcn standard. `true` if `window.innerWidth < 768`. SSR-safe. |
| `use-online-status.ts` | `navigator.onLine` via `useSyncExternalStore` (tears-free). |
| `use-scan-queue.ts` | Offline-first scan queue. localStorage `ng_scan_queue_v2`. Exponential backoff + jitter. After 5 attempts → `failed` (manual retry). Deterministic idempotency key prevents re-drain duplicates. |
| `use-session-timeout.ts` | 30-min inactivity auto-logout (25-min warning). Tracks `mousedown`/`keydown`/`touchstart`/`scroll`. Checks every 30 s. |
| `use-toast.ts` | shadcn toast singleton (TOAST_LIMIT=1, ~16 min memory retention). |

---

## 11. Security Posture (defense-in-depth, 8 layers)

1. **Auth** — Supabase Auth + 3 sign-in methods + brute-force lockout + orphan reconciliation.
2. **Authz** — RBAC hierarchy (`USER < ORGANIZER < ADMIN`); `requireAuth` on every authenticated route; 30-s account cache; maintenance-mode block for non-ADMIN.
3. **Validation** — Zod 4 schemas on every API input; server-side password strength scorer shared with client meter (cannot be bypassed client-side); strict section format (`<digits>-<letters>`); year-prefix consistency.
4. **CSRF** — Same-origin Origin/Referer check on POST/PATCH/PUT/DELETE (port-insensitive hostname compare) in `proxy.ts`; dev allows localhost + trusted forwarded hosts.
5. **Rate limiting** — Upstash (prod, fails OPEN on errors) + in-memory (dev). Per-IP presets (`login`, `register`, `otp`) + per-account presets (`api`, `scan` — scan is account-only to support school WiFi shared IP). `apiAccount` 100/min auto-applied on every authed route.
6. **Crypto** — Ed25519 device-bound scan certificates; timing-safe HMAC comparisons; bcrypt cost 12; deterministic idempotency keys; 60 s forward / 24 h backward timestamp skew tolerance.
7. **DB security** — RLS on all 11 tables (defense-in-depth if anon key leaks); service-role bypass; `guard_account_columns` trigger blocks REST API self-escalation; CHECK constraints on enum columns; `is_admin()` SECURITY DEFINER helper.
8. **HTTP headers** — Strict CSP (no `unsafe-eval`, `connect-src: self + *.ably.io + *.ably.net`), X-Frame-Options (DENY prod / SAMEORIGIN dev), HSTS preload 1 yr, Permissions-Policy (camera=self, microphone=(), geolocation=()), X-XSS-Protection: 0, nosniff, Referrer-Policy strict-origin-when-cross-origin.

**Plus**: SSRF defense on push-subscription endpoints; strict file ext + MIME allowlist on whitelist import; Cloudflare Turnstile (with circuit breaker + fail-open on infra errors / fail-closed on token errors); cron-auth multi-method (Bearer / Basic / headers / query / body) with constant-time comparison.

---

## 12. PWA / Offline Capabilities

- **manifest.json**: standalone, portrait, theme `#b45309` (amber-700), background `#fffef7` (cream), 2 SVG icons (192/512) with `purpose: "any maskable"`, shortcut `/?action=scan` → "Scan to check in".
- **sw.js** (`nexus-gate-v1` cache):
  - App shell (`/`, `/manifest.json`, icons) — pre-cached on install, `skipWaiting()`.
  - API GETs — **network-first** (fall back to cached, then 503 JSON).
  - Other same-origin GETs (HTML/CSS/JS/fonts/images) — **stale-while-revalidate**.
  - Activate: deletes all caches ≠ `nexus-gate-v1`, `clients.claim()`. Message listener for `SKIP_WAITING`.
  - Bypass: non-GET requests, cross-origin, Next.js HMR in dev.
- **sw-register.tsx**: prod-only registration. Polls `registration.update()` every 10 min. "Update available" toast → SKIP_WAITING + reload. `beforeinstallprompt` → "Install Nexus Gate" banner after 5 s.
- **Offline-first scanner**: signed scan certificates in localStorage (`ng_scan_queue_v2`) in <1 ms. Drain with backoff + jitter when `navigator.onLine`. Server uses `scannedAt` (client time) for HMAC verification — decouples offline scan from sync time.

⚠ **Unimplemented shortcut**: manifest declares `/?action=scan` but `page.tsx` does NOT read `?action` from the URL — students tapping the homescreen shortcut land on the dashboard, not the scanner. Minor gap.

---

## 13. Observability & Ops

- **Sentry**: 3 configs (`client`/`server`/`edge`). Conditionally enabled only if DSN is set — prevents Vercel "Something went wrong" runtime errors when Sentry is unconfigured. Sourcemaps uploaded + deleted after upload. tracesSampleRate 10% browser / 5% server; replaysOnErrorSampleRate 100% in prod.
- **Audit log**: every mutating route writes via `audit()` (try/catch — never breaks the request). 30+ distinct action types. Stored in `audit_logs` table (JSONB metadata). ADMIN-only viewer with filters.
- **Health check**: `/api/health` does 2-stage DB check (`SELECT 1` + `setting.count`) with 3 s timeout. Public sees `{status, timestamp}`; admin sees `+ checks + uptime`.
- **Cron jobs** (Vercel Cron, also works with cron-job.org):
  - `/api/cron/event-reminders` — daily 8 AM. Finds events starting in next 30 min, creates `reminder` notifications for matching ACTIVE USERs with `notificationEnabled`.
  - `/api/cron/cleanup` — daily 3 AM. Deletes expired verificationTokens + refreshTokens + notifications read >30 days.

---

## 14. Notable Findings, Issues & Concerns

### 14.1 Stale / dead config
1. **NextAuth / Google OAuth env vars are stale** — `env.example` and `example.env` reference `NEXTAUTH_URL`, `NEXTAUTH_SECRET`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, but `package.json` has no `next-auth` dependency. Supabase Auth fully replaced it. Env templates are misleading.
2. **`socket.io` 4.8.3 in deps but unused** — Caddyfile comment confirms "Realtime is now handled by Ably (no local socket.io service)". ~2.5 MB dead dependency.
3. **`pdf-parse` 2.4.5 listed but docs say replaced** — ARCHITECTURE-SECURITY §10 says "pdfjs-dist (replaces pdf-parse — DOMMatrix dependency)" but `pdf-parse` is still in `package.json` and `pdfjs-dist` is NOT installed. Either replacement never happened or docs are wrong.
4. **`.env` and `env.example` are stale** — both contain only `DATABASE_URL=file:/home/z/my-project/db/custom.db`. The real template is `example.env`. The committed `.env` exposes a real (if local-only) path. README correctly points to `example.env`; `env.example` should be deleted or synced.
5. **`package.json` name is leftover scaffold** — `nextjs_tailwind_shadcn_ts` instead of `nexus-gate` or `nexus-gate-web`.

### 14.2 Configuration concerns
6. **`reactStrictMode: false`** — unusual for a "production-ready" app. Typically indicates side-effect-laden code that fails double-invoke in dev.
7. **TypeScript strictness partially defeated** — `strict: true` but `noImplicitAny: false`. Combined with heavily-relaxed ESLint config (almost every quality rule off: `no-explicit-any`, `no-unused-vars`, `exhaustive-deps`, `prefer-const`, `no-console`, `no-debugger`, `no-unreachable`, `no-undef`), the project has minimal static quality enforcement.
8. **Tailwind v4 + v3-style `tailwind.config.ts`** — Tailwind v4 uses CSS-based config; the v3-style config file is likely inert. shadcn `components.json` has `"tailwind.config": ""` (empty), confirming partial migration. Both `tailwindcss-animate` AND `tw-animate-css` installed — redundant.
9. **Caddyfile is dev-only and rate-limit is commented out** — Listens on `:81` without TLS; `:80` production block commented out. The rate-limit block (`@api path /api/*; rate_limit @api 100r/m`) is also commented out, despite ARCHITECTURE-SECURITY describing this rate limit as active. **Discrepancy between docs and actual config.**
10. **Vitest config lacks DOM environment** — `environment: "node"` + `globals: false`. All 262 tests are on `src/lib/*` pure-logic helpers; no React component tests. "E2E via Agent Browser" claim is informal (not Playwright/Vitest browser mode).
11. **`z-ai-web-dev-sdk` 0.0.18 in production deps** — dev-tooling SDK, not a typical production dependency. Should be moved to `devDependencies` or removed if not imported in `src/`.

### 14.3 Operational risks
12. **Default admin credentials in README** — `admin@nexusgate.dev` / `AdminPass123!` documented publicly. Initial migration 0001 also bootstraps `admin@ctu.edu.ph` / `nexus123`. If operators don't change these, this is a critical production risk.
13. **`scripts/`, `docs/`, `tests/`, `tool-results/`, `upload/` are gitignored** — but `package.json` references `scripts/bootstrap-admin.ts` and `scripts/seed-events.ts`. These scripts would be missing from a fresh clone, breaking `bun run bootstrap:admin` and `bun run seed:events`.
14. **Cron endpoints rely on a single shared `CRON_SECRET`** — both `/api/cron/event-reminders` and `/api/cron/cleanup` use the same secret. No per-endpoint rotation; if leaked, both endpoints are compromised. Vercel Cron doesn't auto-inject the secret — operators must add `?secret=` to the URL manually, which means the secret ends up in Vercel cron config logs.
15. **Bleeding-edge versions** — Next.js 16.1.1 and React 19.0.0 are very new (late 2025/early 2026). Prisma 6.11, Tailwind v4, Vitest 4, Zod 4 are all latest-major. Risk of ecosystem breakage; the v3→v4 Tailwind migration is clearly incomplete (see #8).

### 14.4 Code-quality observations
16. **DRY violation**: duplicate `NexusLogo` definitions — canonical `components/nexus/nexus-logo.tsx` AND local fn inside `login-screen.tsx`.
17. **`CardErrorBoundary` exported but unused** — available in `error-boundary.tsx` but not observed in any sampled view.
18. **PWA shortcut `/?action=scan` is unimplemented** — manifest declares it but `page.tsx` doesn't read `?action` query param. Students tapping the homescreen shortcut land on dashboard, not scanner.
19. **Theme locked to light by default** — `defaultTheme="light"`, `enableSystem=false`. Users must explicitly opt into dark mode via `ThemeToggle`.
20. **Cloudflare Worker uses `Cache-Control: private` default** — semantically odd; `private` tells CDNs not to cache, but Cloudflare's `caches.default` ignores `private` anyway. `public, s-maxage=15` would be more correct.
21. **No URL-based view routing** — view switching is pure `useState` in `AppShell`. Refresh always returns to dashboard; no shareable deep-links to specific views. (Intentional for an SPA, but limits UX.)
22. **Realtime correctly scoped to organizers only** — students don't need Ably connections, keeping the app well under the 200-connection free-tier limit even at 200 concurrent users.

### 14.5 Test coverage
- **9 test files**, ~262 unit tests, all on `src/lib/*` pure-logic helpers:
  - `auth.test.ts`, `cooldown.test.ts`, `event-visibility.test.ts`, `password-strength.test.ts`, `qr-token.test.ts`, `scan-certificate.test.ts`, `scan-flow.integration.test.ts`, `section-validation.test.ts`, `validation.test.ts`
- No React component tests (Vitest configured for node env only).
- No Playwright/E2E test config — "E2E via Agent Browser" is informal.

---

## 15. Summary

**Nexus Gate is a sophisticated, security-first attendance system** with a genuinely impressive anti-cheating stack (Ed25519 device-bound certificates + multi-frame liveness + offline-first sync queue + 10-step server verification). The architecture is well-documented across 4 markdown files, and the security model is defense-in-depth with RLS, guard triggers, CHECK constraints, CSRF, rate limiting, SSRF defense, and timing-safe comparisons.

**Strengths:**
- Anti-cheating design is rigorous and well-reasoned.
- Comprehensive API surface (44 routes) with consistent `requireAuth` gating, audit logging, and cache headers.
- 11-table schema with 10 migrations showing clear evolution; v7 strict RLS + composite indexes; v8 device-key anti-cheating; v10 delegation.
- Strong unit-test coverage on pure security helpers (~262 tests).
- $0/month infra stack on free tiers, with documented scalability target of 2000–3000 users.

**Watch-outs (in priority order):**
1. **Default admin credentials in README + migration 0001 bootstrap** — change before any production deploy.
2. **Caddyfile rate-limit + prod TLS commented out** — docs claim active, config says inactive.
3. **Stale env templates + dead `next-auth`/`socket.io` deps** — confusing for new operators.
4. **`reactStrictMode: false` + relaxed ESLint + `noImplicitAny: false`** — minimal static quality enforcement; relies on Zod runtime validation to catch shape errors.
5. **Missing `scripts/` directory in archive** — `bootstrap:admin` and `seed:events` would fail on fresh clone.
6. **PWA shortcut `/?action=scan` unimplemented** — minor UX gap.
7. **Tailwind v3→v4 migration incomplete** — leftover `tailwind.config.ts`, redundant animation libs.

**Recommended next actions** (if continuing work on this codebase):
1. Rotate default admin credentials; remove them from README and migration 0001.
2. Sync `env.example` with `example.env` (or delete the former); remove `NEXTAUTH_*` and `GOOGLE_CLIENT_*` lines.
3. Remove `socket.io` from `package.json`. Either install `pdfjs-dist` and remove `pdf-parse`, or remove the `pdf-parse` mention from docs.
4. Enable the Caddyfile production block + rate-limit; or update ARCHITECTURE-SECURITY to reflect that Caddy is dev-only and Vercel handles prod.
5. Restore or document the missing `scripts/` directory.
6. Implement `?action=scan` deep-link handling in `page.tsx` (or remove the manifest shortcut).
7. Tighten ESLint rules incrementally (start with `no-unused-vars`, `prefer-const`, `@typescript-eslint/no-explicit-any` as warnings).
8. Consider adding Playwright or Vitest browser-mode E2E tests for the golden-path scan flow.

---

*Report compiled by Z.ai Code from 5 parallel subagent analyses. Per-area stage summaries are in `/home/z/my-project/worklog.md` (Tasks 1, 2-3, 4, 5, 6, 7-8).*
